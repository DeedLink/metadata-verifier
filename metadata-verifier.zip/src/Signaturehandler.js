import { GetObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { ethers } from "ethers";

dotenv.config();

const s3 = new S3Client({
    region: process.env.AWS_REGION,
    credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    },
});

const Signaturehandler = async (event) => {

    try {
        const tokenId = event.queryStringParameters.tokenId;

        if (!tokenId) {
            return {
                statusCode: 400,
                body: JSON.stringify({
                    message: "tokenId required!"
                }),
            };
        }

        //Fetch metadata from s3
        const signKey = `signature/${tokenId}.json`;
        const signCmd = new GetObjectCommand({
            Bucket: process.env.AWS_BUCKET_NAME,
            Key: signKey
        });

        const signObj = await s3.send(signCmd);
        let signRaw = "";

        for await (const chunk of signObj.Body) {
            signRaw += chunk;
        }

        //Get off-chain signature
        const offChainSignature = JSON.parse(signRaw);

        return {
            statusCode: 200,
            body: JSON.stringify({
                message: "Signature fetched successfully",
                data: offChainSignature
            }),
        };

        //Get on-chain signature
        const provider = new ethers.JsonRpcProvider(process.env.RPC_URL);
        const contract = new ethers.Contract(
            process.env.CONTRACT_ADDRESS,
            PropertyNFTABI,
            provider
        );

        const onChain = await contract.getSignature(tokenId);

        const onChainSigature = {
            surveyor: onChain.surveyor,
            notary: onChain.notary,
            ivsl: onChain.ivsl
        };

        if (onChainSigature && Object.values(onChainSigature).every(v => v)) {
            return {
                statusCode: 200,
                body: JSON.stringify({
                    message: "On-chain signatures fetched successfully!",
                    data: onChainSigature
                })
            };
        } else {
            return {
                statusCode: 404,
                body: JSON.stringify({
                    message: "On-chain signatures not found or incomplete."
                })
            };
        }

        //Signature comparison
        const result = {
            tokenId: tokenId,
            onChian: onChainSigature,
            offChain: offChainSignature,
            isMatches: {
                surveyor:
                    onChainSigature.surveyor.toLowerCase() === offChainSignature.surveyor.toLowerCase(),
                noatry:
                    onChainSigature.notary.toLowerCase() === offChainSignature.notary.toLowerCase(),
                ivsl:
                    onChainSigature.ivsl.toLowerCase() === offChainSignature.ivsl.toLowerCase(),
            }
        };

        return {
            statusCode: 200,
            body: JSON.stringify({
                message: "Signature compaired successfully",
                data: result
            }),
        }

    } catch (error) {
        console.error("Error in signature verification:", error);
        return{
            statusCode: 500,
            body: JSON.stringify({
                message: "Internal Server Error",
                error: error.message
            })
        }
    }
}

export default Signaturehandler;